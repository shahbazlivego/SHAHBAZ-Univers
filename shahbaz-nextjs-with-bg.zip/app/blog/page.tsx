export default function Page() {
  return (
    <section className="min-h-[70vh] flex items-center justify-center text-center bg-black/40 backdrop-blur">
      <div className="max-w-3xl mx-auto p-8">
        <h1 className="text-4xl md:text-5xl font-extrabold text-shahbaz-gold gold-glow">Blog</h1>
        <p className="mt-4 text-lg text-white/90">Write, publish, and share your stories.</p>
      </div>
    </section>
  );
}
