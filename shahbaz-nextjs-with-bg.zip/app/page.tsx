import FeatureCard from "@/components/FeatureCard";

export default function Home() {
  return (
    <section>
      <div className="text-center pt-24 pb-12 bg-black/40 backdrop-blur">
        <h1 className="text-5xl md:text-6xl font-extrabold text-shahbaz-gold gold-glow">Welcome to SHAHBAZ</h1>
        <p className="mt-4 text-xl">Your Universal Platform for Everything</p>
      </div>
      <div className="max-w-6xl mx-auto px-4 py-10 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
        <FeatureCard src="/assets/icons/login.svg" title="Secure Login" desc="Access your personal dashboard and tools safely." />
        <FeatureCard src="/assets/icons/dashboard.svg" title="Smart Dashboard" desc="Control and monitor all your actions in one place." />
        <FeatureCard src="/assets/icons/blog.svg" title="Creative Blog" desc="Share ideas, updates, and stories visually." />
        <FeatureCard src="/assets/icons/store.svg" title="Online Store" desc="Shop digital products with smooth transactions." />
        <FeatureCard src="/assets/icons/info.svg" title="About Us" desc="Discover the vision and mission behind SHAHBAZ." />
        <FeatureCard src="/assets/icons/gallery.svg" title="Gallery" desc="Explore creative media and moments in 3D." />
        <FeatureCard src="/assets/icons/contact.svg" title="Contact" desc="Connect with us for help, feedback, or ideas." />
      </div>
    </section>
  );
}
